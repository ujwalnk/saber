import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:saber/components/settings/settings_row.dart';
import 'package:saber/components/theming/adaptive_toggle_buttons.dart';
import 'package:saber/components/theming/uni_icon.dart';
import 'package:saber/pages/home/settings.dart';
import 'package:stow/stow.dart';
import 'package:yaru/yaru.dart';

class SettingsDropdown<T> extends StatefulWidget {
  const new({
    super.key,
    required this.title,
    this.subtitle,
    this.icon,
    this.iconBuilder,
    required this.pref,
    required this.options,
    this.afterChange,
  }) : assert(
         icon == null || iconBuilder == null,
         'Cannot set both icon and iconBuilder',
       );

  final String title;
  final String? subtitle;
  final Object? icon;
  final Object? Function(T)? iconBuilder;

  final Stow<dynamic, T, dynamic> pref;
  final List<ToggleButtonsOption<T>> options;
  final ValueChanged<T>? afterChange;

  int? indexOf(T value) {
    for (int i = 0; i < options.length; i++) {
      if (options[i].value == value) return i;
    }
    return null;
  }

  @override
  State<SettingsDropdown> createState() => _SettingsDropdownState<T>();
}

class _SettingsDropdownState<T> extends State<SettingsDropdown<T>> {
  @override
  void initState() {
    widget.pref.addListener(onChanged);
    super.initState();
  }

  void onChanged() {
    widget.afterChange?.call(widget.pref.value);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    if (widget.indexOf(widget.pref.value) == null) {
      if (kDebugMode)
        throw Exception(
          'SettingsDropdown (${widget.pref.key}): Value ${widget.pref.value} is not in the list of values, set it to ${widget.options.first.value}?',
        );
      widget.pref.value = widget.options.first.value;
    }

    var icon = widget.icon;
    icon ??= widget.iconBuilder?.call(widget.pref.value);
    icon ??= Icons.settings;

    final colorScheme = ColorScheme.of(context);

    return MergeSemantics(
      child: SettingsRow(
        child: ListTile(
          onLongPress: () {
            SettingsPage.showResetDialog(
              context: context,
              pref: widget.pref,
              prefTitle: widget.title,
            );
          },
          contentPadding: EdgeInsets.zero,
          leading: AnimatedSwitcher(
            duration: const Duration(milliseconds: 100),
            child: UniIcon(icon, key: ValueKey(icon)),
          ),
          title: Text(
            widget.title,
            style: TextStyle(
              fontSize: 15,
              fontStyle: widget.pref.value != widget.pref.defaultValue
                  ? FontStyle.italic
                  : null,
            ),
          ),
          subtitle: widget.subtitle != null && widget.subtitle!.isNotEmpty
              ? Text(
                  widget.subtitle!,
                  style: TextStyle(
                    fontSize: 13,
                    color: colorScheme.onSurfaceVariant,
                  ),
                )
              : null,
          trailing: YaruPopupMenuButton<T>(
          initialValue: widget.pref.value,
          onSelected: (value) => widget.pref.value = value,
          style:
              OutlinedButtonTheme.of(context).style ??
              OutlinedButton.styleFrom(
                shape: const RoundedRectangleBorder(
                  borderRadius: .all(.circular(8)),
                ),
              ),
          itemBuilder: (context) => [
            for (final option in widget.options)
              PopupMenuItem(
                value: option.value,
                child: ConstrainedBox(
                  constraints: BoxConstraints(
                    maxWidth: MediaQuery.sizeOf(context).width * 0.45,
                  ),
                  child: Padding(
                    padding: const .symmetric(horizontal: 16),
                    child: option.widget,
                  ),
                ),
              ),
          ],
          child: widget.options
              .firstWhere((option) => option.value == widget.pref.value)
              .widget,
        ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    widget.pref.removeListener(onChanged);
    super.dispose();
  }
}
