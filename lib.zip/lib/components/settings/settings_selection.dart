import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:saber/components/settings/settings_dropdown.dart';
import 'package:saber/components/settings/settings_row.dart';
import 'package:saber/components/theming/adaptive_toggle_buttons.dart';
import 'package:saber/components/theming/uni_icon.dart';
import 'package:saber/pages/home/settings.dart';
import 'package:stow/stow.dart';

class SettingsSelection<T extends num> extends StatefulWidget {
  const new({
    super.key,
    required this.title,
    this.subtitle,
    this.icon,
    this.iconBuilder,
    required this.pref,
    required this.options,
    this.afterChange,
    this.optionsWidth = 72,
    this.optionsHeight = 40,
  }) : assert(
         icon == null || iconBuilder == null,
         'Cannot set both icon and iconBuilder',
       );

  final String title;
  final String? subtitle;
  final Object? icon;
  final Object? Function(T)? iconBuilder;

  final Stow<dynamic, T, dynamic> pref;
  final List<ToggleButtonsOption<T>> options;
  final ValueChanged<T>? afterChange;

  final double optionsWidth, optionsHeight;

  @override
  State<SettingsSelection> createState() => _SettingsSelectionState<T>();
}

class _SettingsSelectionState<T extends num>
    extends State<SettingsSelection<T>> {
  late final dropdownFocusNode = FocusNode(
    debugLabel: 'dropdownFocusNode(${widget.pref.key})',
  );

  @override
  void initState() {
    widget.pref.addListener(onChanged);
    super.initState();
  }

  void onChanged() {
    widget.afterChange?.call(widget.pref.value);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.options.any(
      (ToggleButtonsOption option) => widget.pref.value == option.value,
    )) {
      if (kDebugMode)
        throw Exception(
          'SettingsSelection (${widget.pref.key}): Value ${widget.pref.value} is not in the list of values, set it to ${widget.options.first.value}?',
        );
      widget.pref.value = widget.options.first.value;
    }

    final expSelectionWidth = widget.options.length * widget.optionsWidth;
    final useDropdownInstead =
        MediaQuery.sizeOf(context).width * 0.48 < expSelectionWidth;
    if (useDropdownInstead) {
      // Use dropdown if there isn't enough horizontal space
      return SettingsDropdown<T>(
        pref: widget.pref,
        options: widget.options,
        title: widget.title,
        subtitle: widget.subtitle,
        icon: widget.icon,
        iconBuilder: widget.iconBuilder,
        afterChange: widget.afterChange,
      );
    }

    var icon = widget.icon;
    icon ??= widget.iconBuilder?.call(widget.pref.value);
    icon ??= Icons.settings;

    final colorScheme = ColorScheme.of(context);

    return SettingsRow(
      child: ListTile(
        onTap: () {
          // cycle through options
          final int i = widget.options.indexWhere(
            (ToggleButtonsOption option) => option.value == widget.pref.value,
          );
          widget.pref.value =
              widget.options[(i + 1) % widget.options.length].value;
        },
        onLongPress: () {
          SettingsPage.showResetDialog(
            context: context,
            pref: widget.pref,
            prefTitle: widget.title,
          );
        },
        contentPadding: EdgeInsets.zero,
        leading: AnimatedSwitcher(
          duration: const Duration(milliseconds: 100),
          child: UniIcon(icon, key: ValueKey(icon)),
        ),
        title: Text(
          widget.title,
          style: TextStyle(
            fontSize: 15,
            fontStyle: widget.pref.value != widget.pref.defaultValue
                ? FontStyle.italic
                : null,
          ),
        ),
        subtitle: widget.subtitle != null && widget.subtitle!.isNotEmpty
            ? Text(
                widget.subtitle!,
                style: TextStyle(
                  fontSize: 13,
                  color: colorScheme.onSurfaceVariant,
                ),
              )
            : null,
        trailing: AdaptiveToggleButtons(
          value: widget.pref.value,
          options: widget.options,
          onChange: (T? value) {
            // setState is automatically called when the pref changes
            if (value != null) {
              widget.pref.value = value;
            }
          },
          optionsWidth: widget.optionsWidth,
          optionsHeight: widget.optionsHeight,
        ),
      ),
    );
  }

  @override
  void dispose() {
    widget.pref.removeListener(onChanged);
    super.dispose();
  }
}
